<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Crear Producto</title>
  </head>
  <body>
    <section class="container mt-5">
      @if(session('success'))
      <div class="alert alert-success">{{session('success')}}</div>
      @endif
      <div class="card">
        <div class="card-header">Editar Producto</div>
        <div class="card-body">
          <form action="{{route('productos.update', $data->id)}}" method="post">
            @csrf
            @method('PATCH')
            <div class="form-group">
              <label>Producto</label>
              <input type="text" name="nombre" class="form-control" value="{{$data->nombre}}" required></input>
              @error('nombre')<p class="text text-danger">{{ $message }}</p>@enderror
            </div>
            <div class="form-group">
              <label>Descripción</label>
              <input type="text" name="descripcion" class="form-control" value="{{$data->descripcion}}" required></input>
              @error('descripcion')<p class="text text-danger">{{ $message }}</p>@enderror
            </div>
            <div class="form-group">
              <label>Precio</label>
              <input type="decimal" name="precio" class="form-control" value="{{$data->precio}}" required pattern="[0-9]{10}" maxlength="15" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;"></input>
              @error('precio')<p class="text text-danger">{{ $message }}</p>@enderror
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
            <a href="{{route('productos.index')}}" class="btn btn-secundary">Lista de Productos</a>
          </form>
        </div>
        <div class="card-footer">

        </div>
      </div>
    </section>



  </body>
</html>
