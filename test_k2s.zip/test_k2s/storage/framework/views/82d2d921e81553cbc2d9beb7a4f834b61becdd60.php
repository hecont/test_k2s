<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Productos</title>
  </head>
  <body>
    <section class="container mt-5">
      <?php if(session('success')): ?>
      <div class="alert alert-success"><?php echo e(session('success')); ?></div>
      <?php endif; ?>
      <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Producto</th>
            <th scope="col">Descripción</th>
            <th scope="col">Precio</th>
            <th scope="col">Accciones<a href="<?php echo e(route('productos.create')); ?>" class="btn btn-secundary">Nuevo Producto</a></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e(++$key); ?></th>
            <td><?php echo e($value->nombre); ?></td>
            <td><?php echo e($value->descripcion); ?></td>
            <td><?php echo e($value->precio); ?></td>
            <td>
                <a href="<?php echo e(route('productos.edit', $value->id)); ?>" class="btn btn-secundary">Editar</a>
                <a href="<?php echo e(route('productos.show', $value->id)); ?>" class="btn btn-danger">Eliminar</a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
        </tbody>
      </table>
    </section>



  </body>
</html>
<?php /**PATH C:\xampp\htdocs\test_k2s\resources\views/productos/index.blade.php ENDPATH**/ ?>